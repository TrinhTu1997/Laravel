<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Http\Request;

Route::get('/', function () {
    return view('welcome');
});
Route::group(['prefix' => 'admin'], function () {
    Route::group(['prefix' => 'products'], function () {
        Route::get('list', 'ProductsController@getList');
        Route::get('edit/{id}', 'ProductsController@getEdit')->where('id', '[0-9]+');
        Route::post('edit/{id}', 'ProductsController@postEdit')->where('id', '[0-9]+');
        Route::get('add', 'ProductsController@getAdd');
        Route::post('add', 'ProductsController@postAdd');
        Route::get('delete/{id}', 'ProductsController@getDelete')->where('id', '[0-9]+');

    });
});

