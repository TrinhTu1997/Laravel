<?php $__env->startSection('content'); ?>
    <!-- Page Content -->
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Product
                        <small>Add</small>
                    </h1>
                </div>
                <!-- /.col-lg-12 -->
                <div class="col-lg-7" style="padding-bottom:120px">
                    <form action="admin/products/edit/<?php echo e($product->id); ?>" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="form-group">
                            <label>Name</label>
                            <input class="form-control" name="name" placeholder="Please Enter Name"
                                   value="<?php echo e($product->name); ?>"/>
                        </div>
                        <div class="form-group">
                            <label>Price</label>
                            <input class="form-control" name="price" placeholder="Please Enter Price"
                                   value="<?php echo e($product->price); ?>"/>
                        </div>
                        <div class="form-group">
                            <label>Images</label>
                            <input type="file" name="image" value="<?php echo e($product->image); ?>">
                            <img src="<?php echo e($product->image); ?>"  value="<?php echo e($product->image); ?>" width="70">
                        </div>

                        <div class="form-group">
                            <label>amount</label>
                            <input class="form-control" name="amount" placeholder="Please Enter Amount"
                                   value="<?php echo e($product->amount); ?>"/>
                        </div>

                        <div class="form-group">
                            <label>Detail</label>
                            <textarea class="form-control" rows="3" name="detail"><?php echo e($product->detail); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Product Status</label>
                            <label class="radio-inline">
                                <input name="status" value="0" type="radio" <?php if($product->status==0): ?> checked <?php endif; ?>>Noi bat
                            </label>
                            <label class="radio-inline">
                                <input name="status" value="1" type="radio" <?php if($product->status==1): ?> checked <?php endif; ?>>Khong noi bat
                            </label>
                        </div>
                        <button type="submit" class="btn btn-default">Product Add</button>
                        <button type="reset" class="btn btn-default">Reset</button>
                        <form>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Workspace/lesson1/resources/views/admin/products/edit.blade.php ENDPATH**/ ?>