<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
            <li class="sidebar-search">
                <form action="" method="GET">
                    <div class="input-group custom-search-form">
                        <input type="text" class="form-control" placeholder="Search..." name="keyword" value="">
                        <span class="input-group-btn">
                                    <button class="btn btn-default" >
                                   <i class="fa fa-search"></i>
                                    </button>
                                </span>
                    </div>
                </form>

                <!-- /input-group -->
            </li>
            <li>
                <a href="#"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
            </li>
            <li>
                <a href="#"><i class="fa fa-cube fa-fw"></i> Product<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="admin/products/list">List Product</a>
                    </li>
                    <li>
                        <a href="admin/products/add">Add Product</a>
                    </li>
                </ul>
                <!-- /.nav-second-level -->
        </ul>
    </div>
    <!-- /.sidebar-collapse -->
</div>
<?php /**PATH /opt/lampp/htdocs/Workspace/lesson1/resources/views/admin/layout/menu.blade.php ENDPATH**/ ?>