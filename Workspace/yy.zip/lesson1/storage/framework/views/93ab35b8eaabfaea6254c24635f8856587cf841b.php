<form action="" method="get">
	<input type="text" name="keyword" placeholder="Tìm kiếm.......">
<!-- 	<input type="text" name="name" placeholder="Name......."> -->
	<button>Submit</button>
</form>
<table style="border: 1px solid black">
	<thead>
		 <tr>
	      <th>ID</th>
	      <th>NAME</th>
	      <th>PRICE</th>
	      <!-- <th>DETAIL</th> -->
	      <th>IMAGE</th>
	    </tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($pr->id); ?></td>
			<td><?php echo e($pr->name); ?></td>
			<td><?php echo e($pr->price); ?></td>
			<!-- <td><?php echo e($pr->detail); ?></td> -->
			<td>
				<img src="<?php echo e($pr->image); ?>" width="70">
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table><?php /**PATH C:\Users\Admin\Desktop\Workspace\lesson1\resources\views/view-product.blade.php ENDPATH**/ ?>