<?php $__env->startSection('content'); ?>
    <!-- Page Content -->
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Product
                        <small>List</small>
                    </h1>
                    <div style="width: 80px;height: 40px;background-color: yellow;line-height: 40px;text-align:center;font-weight: bold;border: 1px solid #000000;border-radius: 10px;float: right;
">
                        <a href="admin/products/add" style="text-decoration: none">Thêm mới</a>
                    </div>

                </div>

                <!-- /.col-lg-12 -->
                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead>
                    <tr align="center">
                        <th>ID</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Img</th>
                        <th>Detail</th>
                        <th>amount</th>
                        <th>Status</th>
                        <th>Delete</th>
                        <th>Edit</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="odd gradeX" align="center">
                            <td><?php echo e($pr->id); ?></td>
                            <td><?php echo e($pr->name); ?></td>
                            <td><?php echo e($pr->price); ?></td>
                            <td>
                                <img src="<?php echo e($pr->image); ?>" width="70">
                            </td>
                            <td><?php echo e($pr->detail); ?></td>
                            <td><?php echo e($pr->amount); ?></td>
                            <td><?php echo e($pr->status); ?></td>
                            <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a
                                    onclick="return confirm('Ban co that su muon xoa!')"
                                    href="admin/products/delete/<?php echo e($pr->id); ?>"> Delete</a></td>
                            <td class="center"><i class="fa fa-pencil fa-fw"></i> <a
                                    href="admin/products/edit/<?php echo e($pr->id); ?>">Edit</a></td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
                <div style="width: 50%;margin: auto">  <?php echo $product->links(); ?></div>

            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Workspace/lesson1/resources/views/admin/products/list.blade.php ENDPATH**/ ?>