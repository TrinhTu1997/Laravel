<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Product;
use Illuminate\Database;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input as Input;
use Illuminate\Validation\Rules\In;


class ProductsController extends Controller
{
    public function getList(Request $request)
    {
        if (!$request->has('keyword') || empty($request->keyword)) {
            $product = DB::table('products')->orderBy('id', 'desc')
                ->paginate(10);
        } else {
            $kw = $request->keyword;
            $product = Product::where('name', 'like', "%$kw%")
                ->orWhere('id', 'like', "%$kw%")
                ->orWhere('detail','like', "%$kw%")
                ->orderBy('id', 'desc')
                ->paginate(10);
        }
        return view('admin.products.list', ['product' => $product]);
    }

    public function getAdd()
    {
        return view('admin.products.add');

    }

    public function postAdd(Request $request)
    {

        $product = new Product;
        $product->name = $request->name;
        $product->price = $request->price;
        $product->image = $request->image;
        $product->amount = $request->amount;
        $product->detail = $request->detail;
        $product->status = $request->status;
        $product->save();
        return redirect('admin/products/list');
    }

    public function getEdit($id)
    {
        $product = Product::find($id);
        return view('admin.products.edit', ['product' => $product]);
    }

    public function postEdit(Request $request, $id)
    {
        $product = Product::find($id);
        $product->name = $request->name;
        $product->price = $request->price;
        $product->image = $request->image;
        $product->amount = $request->amount;
        $product->detail = $request->detail;
        $product->status = $request->status;
        $product->save();
        return redirect('admin/products/list');
    }

    public function getDelete($id)
    {
        Product::destroy($id);
        return back();
    }


}
