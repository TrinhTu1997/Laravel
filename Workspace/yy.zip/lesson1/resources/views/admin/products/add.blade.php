@extends('admin.layout.index')
@section('content')
    <!-- Page Content -->
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Product
                        <small>Add</small>
                    </h1>
                </div>
                <!-- /.col-lg-12 -->
                <div class="col-lg-7" style="padding-bottom:120px">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="{{csrf_token()}}">
                        <div class="form-group">
                            <label>Name</label>
                            <input class="form-control" name="name" placeholder="Please Enter Name"/>
                        </div>
                        <div class="form-group">
                            <label>Price</label>
                            <input class="form-control" name="price" placeholder="Please Enter Price"/>
                        </div>

                        <div class="form-group">
                            <label>Images</label>
                            <input type="file" name="image">
                        </div>
                        <div class="form-group">
                            <label>amount</label>
                            <input class="form-control" name="amount" placeholder="Please Enter Amount"/>
                        </div>
                        <div class="form-group">
                            <label>Detail</label>
                            <textarea class="form-control" rows="3" name="detail"></textarea>
                        </div>
                        <div class="form-group">
                            <label>Product Status</label>
                            <label class="radio-inline">
                                <input name="status" value="0" checked="" type="radio">Noi Bat
                            </label>
                            <label class="radio-inline">
                                <input name="status" value="1" type="radio">Khong Noi Bat
                            </label>
                        </div>
                        <button type="submit" class="btn btn-default">Product Add</button>
                        <button type="reset" class="btn btn-default">Reset</button>
                        <form>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->
@endsection
